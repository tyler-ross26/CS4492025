class PegSolitaire:

    def __init__(self, board_size=7, board_type="English"):
        self.board_size = board_size
        self.board_type = board_type
        self.new_game()

    def initialize_board(self):
        center = self.board_size // 2
        # Initialize the board based on the selected size and type, allowing sizes ranging from 5 to 15 and types "English", "Diamond", or "Hexagonal"
        if self.board_size not in [5, 7, 9, 11, 13, 15]:
            raise ValueError("Board size must be an odd number between 5 and 15.")
        elif self.board_type not in ["English", "Diamond", "Hexagonal"]:
            raise ValueError("Board type must be 'English', 'Diamond', or 'Hexagonal'.")
        elif self.board_type == "English":
            # Create a 2D list representing the English board
            # Scale the width of the cross with the board size
            arm_width = max(1, self.board_size // 3)
            half_width = arm_width // 2
            return [
                [
                    1 if (
                        abs(i - center) <= half_width or
                        abs(j - center) <= half_width
                    ) else None
                    for j in range(self.board_size)
                ]
                for i in range(self.board_size)
            ]
        elif self.board_type == "Diamond":
            # Create a 2D list representing the Diamond board
            board = [[None for _ in range(self.board_size)] for _ in range(self.board_size)]
            center = self.board_size // 2
            for row in range(self.board_size):
                for col in range(self.board_size):
                    if abs(row - center) + abs(col - center) <= center:
                        board[row][col] = 1  # Peg present
                    else:
                        board[row][col] = None  # Invalid position
            return board
        elif self.board_type == "Hexagonal":
            return [
                [
                    1 if (
                        abs(i - center) <= center and
                        abs(j - center) <= center and
                        abs((i - center) + (j - center)) <= center
                    ) else None
                    for j in range(self.board_size)
                ]
                for i in range(self.board_size)
            ]

    def change_board(self, board_size, board_type):
        if board_size not in [5, 7, 9, 11, 13, 15]:
            raise ValueError("Board size must be an odd number between 5 and 15.")
        if board_type not in ["English", "Diamond", "Hexagonal"]:
            raise ValueError("Board type must be 'English', 'Diamond', or 'Hexagonal'.")
        self.board_size = board_size
        self.board_type = board_type
        self.new_game()

    def new_game(self):
        # Reset the board to the initial state
        self.board = self.initialize_board()
        # Set the center position to empty
        center = self.board_size // 2
        self.board[center][center] = 0

    def is_valid_move(self, start_pos, end_pos):
        # Validate if a move from start_pos to end_pos is valid
        start_row, start_col = start_pos
        end_row, end_col = end_pos

        # Check board boundaries
        if not (0 <= start_row < self.board_size and
            0 <= start_col < self.board_size and
            0 <= end_row < self.board_size and
            0 <= end_col < self.board_size):
            return False

        row_diff = start_row - end_row
        col_diff = start_col - end_col

        if (row_diff, col_diff) not in self.get_directions():
            return False

        mid_row = (start_row + end_row) // 2
        mid_col = (start_col + end_col) // 2

        return (
            self.board[start_row][start_col] == 1 and
            self.board[mid_row][mid_col] == 1 and
            self.board[end_row][end_col] == 0
        )

    def make_move(self, start_pos, end_pos):
        if self.is_game_over():
            return False  # No moves can be made if the game is over

        if not self.is_valid_move(start_pos, end_pos):
            return False  # Move is invalid

        start_row, start_col = start_pos
        end_row, end_col = end_pos

        mid_row = (start_row + end_row) // 2
        mid_col = (start_col + end_col) // 2

        self.board[start_row][start_col] = 0
        self.board[mid_row][mid_col] = 0
        self.board[end_row][end_col] = 1
        
        return True

    def get_directions(self):
        # Return the possible jump directions based on the board type
        if self.board_type == "Hexagonal":
            return [(-2, 0), (2, 0), (0, -2), (0, 2), (-2, 2), (2, -2)]
        else:
            return [(-2, 0), (2, 0), (0, -2), (0, 2), (-2, -2), (-2, 2), (2, -2), (2, 2)]

    def has_valid_moves(self):
        directions = self.get_directions()

        # Check if there are any valid moves left
        for row in range(self.board_size):
            for col in range(self.board_size):
                if self.board[row][col] == 1:
                    # Check all possible jump directions
                    for dr, dc in directions:
                        end_row = row + dr
                        end_col = col + dc
                        if self.is_valid_move((row, col), (end_row, end_col)):
                            return True

        return False

    def is_game_over(self):
        return not self.has_valid_moves()

    def get_game_result(self):
        if self.is_game_over():
            remaining_pegs = sum(row.count(1) for row in self.board)
            if remaining_pegs == 1:
                return "Win"
            else:
                return "Lose"
        else:
            return "Game is still in progress"