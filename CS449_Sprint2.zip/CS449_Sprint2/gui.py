
import tkinter as tk
from game import PegSolitaire


class PegSolitaireGUI:

    def __init__(self, root):
        self.root = root
        self.root.title("Peg Solitaire")
        self.root.geometry("950x650")

        # Create the game
        self.game = PegSolitaire()
        self.selected_peg = None

        # Title
        title = tk.Label(root, text="Peg Solitaire", font=("Arial", 24, "bold"))
        title.pack(pady=20)

        # Main layout
        main_frame = tk.Frame(root)
        main_frame.pack(fill="both", expand=True)

        # Left, center, and right sections
        self.left_frame = tk.Frame(main_frame, width=180)
        self.board_frame = tk.Frame(main_frame)
        self.right_frame = tk.Frame(main_frame, width=180)

        self.left_frame.pack(side="left", fill="y", padx=20)
        self.board_frame.pack(side="left", expand=True)
        self.right_frame.pack(side="right", fill="y", padx=20)

        # Board type dropdown
        tk.Label(self.left_frame, text="Board Type").pack(pady=5)

        self.board_type = tk.StringVar(value="English")

        tk.OptionMenu(
            self.left_frame,
            self.board_type,
            "English",
            "Diamond",
            "Hexagonal"
        ).pack(pady=5)

        # Board size dropdown
        tk.Label(self.left_frame, text="Board Size").pack(pady=5)

        self.board_size = tk.IntVar(value=7)

        tk.OptionMenu(
            self.left_frame,
            self.board_size,
            5, 7, 9, 11, 13, 15
        ).pack(pady=5)

        # New game button
        tk.Button(
            self.left_frame,
            text="New Game",
            command=self.new_game
        ).pack(pady=20)

        # Game status
        tk.Label(
            self.right_frame,
            text="Game Status",
            font=("Arial", 14, "bold")
        ).pack(pady=10)

        self.status_label = tk.Label(
            self.right_frame,
            text="Game in progress",
            wraplength=160
        )
        self.status_label.pack(pady=10)

        # Draw the initial board
        self.draw_board()

    def draw_board(self):
        # Clear the old board
        for widget in self.board_frame.winfo_children():
            widget.destroy()

        # Create squares for playable positions
        for row in range(self.game.board_size):
            for col in range(self.game.board_size):

                cell = self.game.board[row][col]

                if cell is None:
                    continue

                # Green = peg, white = empty
                color = "green" if cell == 1 else "white"

                # Highlight selected peg
                if self.selected_peg == (row, col):
                    color = "yellow"

                square = tk.Button(
                    self.board_frame,
                    bg=color,
                    activebackground=color,
                    width=3,
                    height=1,
                    relief="solid",
                    borderwidth=1,
                    command=lambda r=row, c=col: self.click_cell(r, c)
                )

                square.grid(row=row, column=col, padx=1, pady=1)

    def click_cell(self, row, col):
        # Do not allow moves after game over
        if self.game.is_game_over():
            return

        # First click selects a peg
        if self.selected_peg is None:
            if self.game.board[row][col] == 1:
                self.selected_peg = (row, col)

        else:
            # Clicking the selected peg deselects it
            if self.selected_peg == (row, col):
                self.selected_peg = None

            # Clicking another peg changes selection
            elif self.game.board[row][col] == 1:
                self.selected_peg = (row, col)

            # Clicking an empty space attempts a move
            else:
                self.game.make_move(self.selected_peg, (row, col))
                self.selected_peg = None

        self.draw_board()
        self.update_status()

    def new_game(self):
        # Apply selected settings and restart
        self.game.change_board(
            self.board_size.get(),
            self.board_type.get()
        )

        self.selected_peg = None

        self.draw_board()
        self.update_status()

    def update_status(self):
        result = self.game.get_game_result()

        if result == "Win":
            self.status_label.config(text="Game Won!")
        elif result == "Lose":
            self.status_label.config(text="Game Lost!")
        else:
            self.status_label.config(text="Game in progress")


if __name__ == "__main__":
    root = tk.Tk()
    app = PegSolitaireGUI(root)
    root.mainloop()
